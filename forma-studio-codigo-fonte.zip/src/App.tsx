import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { Portfolio } from './components/Portfolio';
import { About } from './components/About';
import { ContactForm } from './components/ContactForm';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';
import { getWhatsAppUrl, WHATSAPP_DISPLAY_PHONE } from './utils/whatsapp';
import { MessageSquare, ArrowRight, Sparkles } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans selection:bg-brand-navy selection:text-white">
      {/* 3-Zone Top Navigation */}
      <Navbar />

      <main className="flex-grow">
        {/* Seção Inicial Impactante (Hero) */}
        <Hero />

        {/* 1. Serviços */}
        <Services />

        {/* 2. Portfólio / Projetos */}
        <Portfolio />

        {/* 3. Sobre / Quem sou */}
        <About />

        {/* Impactful Closing Hero / Call to Action */}
        <section className="py-20 bg-brand-navy text-white relative overflow-hidden">
          {/* Subtle geometric circles and lines */}
          <div
            className="absolute inset-0 pointer-events-none opacity-10"
            style={{
              backgroundImage: 'radial-gradient(circle at 80% 20%, #0288D1 0%, transparent 40%), radial-gradient(circle at 20% 80%, #F5A623 0%, transparent 40%)'
            }}
          />

          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-brand-cyan-light mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span>TRANSFORME SUA PRESENÇA DIGITAL</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight mb-6 text-balance">
              Pronto para transformar sua presença digital em uma obra de arte que vende?
            </h2>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto mb-10 leading-relaxed">
              Diga adeus a sites comuns e genéricos. Converse diretamente com Elisson Barbosa e descubra como a Forma Studio pode valorizar a sua marca.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href={getWhatsAppUrl('Olá, Elisson! Quero agendar uma conversa para iniciar o projeto do meu site/marca.')}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 text-xs font-bold uppercase tracking-wider text-brand-navy bg-white hover:bg-slate-100 rounded-xl shadow-xl transition-all duration-200 active:scale-95"
              >
                <MessageSquare className="w-4 h-4 text-emerald-600" />
                <span>Solicitar Orçamento no WhatsApp</span>
                <ArrowRight className="w-4 h-4 text-slate-600" />
              </a>

              <a
                href="#contato"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-4 text-xs font-semibold uppercase tracking-wider text-white hover:text-brand-cyan-light border border-slate-700 hover:border-slate-500 rounded-xl transition-colors"
              >
                <span>Preencher Formulário de Briefing</span>
              </a>
            </div>

            <p className="text-xs text-slate-400 mt-6">
              Atendimento ágil pelo WhatsApp: <strong className="text-slate-200">{WHATSAPP_DISPLAY_PHONE}</strong>
            </p>
          </div>
        </section>

        {/* 4. Formulário de Contato */}
        <ContactForm />
      </main>

      {/* 5. WhatsApp Flutuante */}
      <FloatingWhatsApp />

      {/* Footer */}
      <Footer />
    </div>
  );
}
