/**
 * WhatsApp integration utilities for Forma Studio
 * Phone: (87) 99178-0107
 */

export const WHATSAPP_RAW_PHONE = '5587991780107';
export const WHATSAPP_DISPLAY_PHONE = '(87) 99178-0107';

export function getWhatsAppUrl(customMessage?: string): string {
  const defaultMessage = 'Olá, Elisson! Gostaria de solicitar um orçamento para um projeto com a Forma Studio.';
  const message = customMessage?.trim() || defaultMessage;
  return `https://wa.me/${WHATSAPP_RAW_PHONE}?text=${encodeURIComponent(message)}`;
}

export function getServiceWhatsAppUrl(serviceTitle: string): string {
  const message = `Olá, Elisson! Estive no site da Forma Studio e tenho interesse no serviço de: *${serviceTitle}*. Gostaria de saber mais e solicitar uma proposta!`;
  return `https://wa.me/${WHATSAPP_RAW_PHONE}?text=${encodeURIComponent(message)}`;
}

export function getProjectWhatsAppUrl(projectTitle: string): string {
  const message = `Olá, Elisson! Vi o projeto *${projectTitle}* no portfólio da Forma Studio e gostaria de desenvolver algo nesse nível para o meu negócio. Podemos conversar?`;
  return `https://wa.me/${WHATSAPP_RAW_PHONE}?text=${encodeURIComponent(message)}`;
}

export const INSTAGRAM_URL = 'https://www.instagram.com/forma.studioart?cplk=MTBqbWtrMzU5eTQ2NA%3D%3D&utm_source=qr';
export const INSTAGRAM_HANDLE = '@forma.estudioart';
