import React from 'react';

export const Portfolio: React.FC = () => {
  return (
    <section id="portfolio" className="py-24 bg-white border-t border-slate-200/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-slate-200">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold tracking-[0.2em] uppercase text-brand-cyan mb-3">
              <span>FORMA STUDIO</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>PORTFÓLIO</span>
            </div>
            <h2 
              className="text-3xl sm:text-4xl font-extrabold text-brand-navy tracking-tight uppercase"
              style={{ fontFamily: "'Space Grotesk', 'Plus Jakarta Sans', sans-serif" }}
            >
              Portfólio
            </h2>
          </div>
        </div>

        {/* Espaço limpo e minimalista: Em construção... */}
        <div className="w-full py-28 sm:py-36 rounded-3xl border-2 border-dashed border-slate-200 bg-[#F8F7F2]/60 flex flex-col items-center justify-center text-center px-4">
          <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-slate-100 text-slate-500 text-xs font-bold uppercase tracking-[0.2em] mb-4">
            <span className="w-2 h-2 rounded-full bg-[#219AB5] animate-pulse" />
            <span>FORMA STUDIO</span>
          </div>

          <h3 
            className="text-2xl sm:text-3xl font-bold text-slate-400 tracking-tight"
            style={{ fontFamily: "'Space Grotesk', 'Plus Jakarta Sans', sans-serif" }}
          >
            Em construção...
          </h3>
        </div>

      </div>
    </section>
  );
};
