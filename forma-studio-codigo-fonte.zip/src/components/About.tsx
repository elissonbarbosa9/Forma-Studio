import React from 'react';
import { getWhatsAppUrl, WHATSAPP_DISPLAY_PHONE } from '../utils/whatsapp';
import { MessageSquare, ArrowRight, MapPin, Sparkles } from 'lucide-react';
import quemSouOriginalImage from '../assets/images/quem_sou_elisson_barbosa.png';

export const About: React.FC = () => {
  return (
    <section id="sobre" className="py-24 bg-white border-t border-slate-200/80 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-slate-200">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold tracking-[0.2em] uppercase text-brand-cyan mb-3">
              <span>FORMA STUDIO</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>QUEM SOU</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-brand-navy tracking-tight text-balance">
              Conheça Elisson Barbosa e a essência criativa da Forma Studio.
            </h2>
          </div>
          
          <div className="mt-4 md:mt-0 flex items-center gap-2 text-xs text-slate-500">
            <MapPin className="w-4 h-4 text-brand-navy shrink-0" />
            <span>Raízes no Nordeste · Atendimento para todo o Brasil</span>
          </div>
        </div>

        {/* Imagem Original Estática Centralizada, Sem Cortes e 100% Responsiva */}
        <div className="flex flex-col items-center">
          <div className="w-full max-w-2xl lg:max-w-3xl flex justify-center">
            <img
              src={quemSouOriginalImage}
              alt="Quem sou — Elisson Barbosa, artista visual e desenvolvedor de mídias da Forma Studio"
              className="w-full h-auto max-w-full rounded-2xl shadow-xl border border-slate-200/80"
              style={{
                width: '100%',
                height: 'auto',
                aspectRatio: '1 / 1',
                objectFit: 'contain',
              }}
            />
          </div>

          {/* Action button */}
          <div className="mt-10 w-full max-w-2xl p-6 sm:p-7 bg-slate-50 rounded-2xl border border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-sm">
            <div className="text-center sm:text-left">
              <div className="flex items-center justify-center sm:justify-start gap-2 text-xs font-bold text-brand-navy uppercase tracking-wider mb-1">
                <Sparkles className="w-4 h-4 text-brand-gold" />
                <span>Atendimento Direto com o Fundador</span>
              </div>
              <p className="text-xs text-slate-600">
                Converse diretamente com Elisson Barbosa no WhatsApp para tirar seu projeto do papel.
              </p>
            </div>

            <a
              href={getWhatsAppUrl('Olá, Elisson! Vi sua apresentação na seção "Quem Sou" da Forma Studio e gostaria de solicitar um orçamento.')}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs font-bold uppercase tracking-wide text-white bg-brand-navy hover:bg-brand-navy-dark rounded-xl shadow-md transition-all active:scale-95 shrink-0"
            >
              <MessageSquare className="w-4 h-4 text-brand-cyan-light" />
              <span>Falar no WhatsApp: {WHATSAPP_DISPLAY_PHONE}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
