import React, { useState, useEffect } from 'react';
import { FormaLogo } from './FormaLogo';
import { getWhatsAppUrl, WHATSAPP_DISPLAY_PHONE, INSTAGRAM_URL, INSTAGRAM_HANDLE } from '../utils/whatsapp';
import { MessageSquare, Menu, X, ArrowUpRight, Instagram } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Serviços', href: '#servicos' },
    { label: 'Portfólio', href: '#portfolio' },
    { label: 'Sobre', href: '#sobre' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-sm py-3.5'
          : 'bg-white/80 backdrop-blur-sm border-b border-slate-100 py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark */}
          <a
            href="#"
            className="flex items-center gap-2.5 group shrink-0"
            aria-label="Forma Studio - Início"
          >
            <FormaLogo variant="compact" size="md" />
          </a>

          {/* Zone 2: Nav Links (Clean, single-line typography, no pill enclosures) */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="hover:text-brand-navy transition-colors whitespace-nowrap shrink-0 relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-brand-navy hover:after:w-full after:transition-all after:duration-200"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: 1 Primary CTA Button + Instagram */}
          <div className="hidden sm:flex items-center gap-3.5 shrink-0">
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-slate-500 hover:text-pink-600 transition-colors rounded-lg hover:bg-slate-100"
              aria-label="Instagram da Forma Studio"
              title={`Instagram ${INSTAGRAM_HANDLE}`}
            >
              <Instagram className="w-4 h-4" />
            </a>

            <span className="hidden xl:inline-block text-xs font-medium text-slate-500 tabular-nums">
              {WHATSAPP_DISPLAY_PHONE}
            </span>

            <a
              href={getWhatsAppUrl('Olá, Elisson! Estive no site da Forma Studio e gostaria de solicitar um orçamento para o meu projeto.')}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold tracking-wide uppercase text-white bg-brand-navy rounded-lg hover:bg-brand-navy-dark transition-all duration-200 shadow-sm hover:shadow active:scale-[0.98] whitespace-nowrap shrink-0"
            >
              <MessageSquare className="w-3.5 h-3.5 text-brand-cyan-light" />
              <span>Solicitar Orçamento</span>
              <ArrowUpRight className="w-3.5 h-3.5 opacity-70" />
            </a>
          </div>

          {/* Mobile hamburger toggle */}
          <div className="flex sm:hidden items-center">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-700 hover:text-brand-navy focus:outline-none"
              aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="sm:hidden bg-white border-b border-slate-200 px-5 pt-3 pb-6 animate-in slide-in-from-top-2 duration-200">
          <nav className="flex flex-col space-y-3 pt-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-base font-medium text-slate-700 hover:text-brand-navy py-2 border-b border-slate-100"
              >
                {link.label}
              </a>
            ))}
            <div className="pt-4 flex flex-col gap-3">
              <a
                href={INSTAGRAM_URL}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200"
              >
                <Instagram className="w-4 h-4 text-pink-600" />
                <span>Instagram {INSTAGRAM_HANDLE}</span>
              </a>

              <span className="text-xs text-slate-500">
                Atendimento direto: <strong className="text-slate-800">{WHATSAPP_DISPLAY_PHONE}</strong>
              </span>
              <a
                href={getWhatsAppUrl('Olá, Elisson! Vim pelo celular através do site da Forma Studio e gostaria de solicitar um orçamento.')}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-brand-navy rounded-lg shadow-sm"
              >
                <MessageSquare className="w-4 h-4 text-brand-cyan-light" />
                <span>Solicitar Orçamento no WhatsApp</span>
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
