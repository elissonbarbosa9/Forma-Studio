import React, { useState } from 'react';
import { getWhatsAppUrl, WHATSAPP_DISPLAY_PHONE } from '../utils/whatsapp';
import { MessageSquare, X } from 'lucide-react';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Speech bubble / Tooltip prompt */}
      {showTooltip && (
        <div className="mb-3 max-w-[240px] bg-white rounded-2xl border border-slate-200/90 shadow-xl p-3.5 relative animate-in fade-in slide-in-from-bottom-2 duration-300">
          <button
            type="button"
            onClick={() => setShowTooltip(false)}
            className="absolute top-2 right-2 text-slate-400 hover:text-slate-600 p-0.5 rounded"
            aria-label="Fechar balão do WhatsApp"
          >
            <X className="w-3.5 h-3.5" />
          </button>
          
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[11px] font-bold text-slate-800">Elisson Barbosa · Online</span>
          </div>
          
          <p className="text-xs text-slate-600 leading-snug">
            Olá! Vamos conversar sobre o site ou identidade visual do seu negócio?
          </p>

          <a
            href={getWhatsAppUrl('Olá, Elisson! Estive navegando no site da Forma Studio e gostaria de conversar.')}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-2 block text-[11px] font-bold text-emerald-600 hover:underline"
          >
            Iniciar conversa agora →
          </a>
        </div>
      )}

      {/* Floating Action Button */}
      <a
        href={getWhatsAppUrl('Olá, Elisson! Vim pelo botão do WhatsApp da Forma Studio e quero um orçamento.')}
        target="_blank"
        rel="noopener noreferrer"
        className="group relative flex items-center justify-center w-14 h-14 bg-emerald-500 hover:bg-emerald-600 text-white rounded-full shadow-2xl hover:shadow-emerald-500/30 transition-all duration-300 hover:scale-110 active:scale-95 focus:outline-none focus:ring-4 focus:ring-emerald-400/40"
        aria-label={`Conversar no WhatsApp: ${WHATSAPP_DISPLAY_PHONE}`}
      >
        {/* Subtle breathing aura */}
        <span className="absolute -inset-1 rounded-full bg-emerald-400 opacity-40 animate-ping -z-10" />

        <MessageSquare className="w-7 h-7 fill-white text-emerald-500 transition-transform group-hover:rotate-6" />

        {/* Small desktop pill badge on hover */}
        <span className="sr-only">Falar no WhatsApp com Forma Studio ({WHATSAPP_DISPLAY_PHONE})</span>
      </a>
    </div>
  );
};
