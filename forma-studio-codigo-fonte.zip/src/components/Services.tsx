import React from 'react';
import { getServiceWhatsAppUrl, getWhatsAppUrl, WHATSAPP_DISPLAY_PHONE } from '../utils/whatsapp';
import { 
  Globe, 
  Layers, 
  Palette, 
  Sparkles, 
  Search, 
  Wrench, 
  ArrowRight, 
  CheckCircle2, 
  MessageSquare,
  ArrowDown
} from 'lucide-react';
import planosImg from '../assets/images/planos_desenvolvimento_sites.png';

interface ServiceCard {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  badge: string;
  tagColor: string;
}

const SERVICES_LIST: ServiceCard[] = [
  {
    id: 'desenvolvimento-sites',
    title: 'Desenvolvimento de Sites',
    description: 'Criamos sites modernos, responsivos e personalizados, desenvolvidos para apresentar negócios, serviços e projetos com profissionalismo.',
    icon: Globe,
    badge: 'Presença Digital',
    tagColor: 'text-[#219AB5] bg-[#219AB5]/10',
  },
  {
    id: 'landing-pages',
    title: 'Landing Pages',
    description: 'Desenvolvemos páginas estratégicas para divulgar produtos, apresentar serviços, campanhas e facilitar a conversão de visitantes em potenciais clientes.',
    icon: Layers,
    badge: 'Alta Conversão',
    tagColor: 'text-[#FF8900] bg-[#FF8900]/10',
  },
  {
    id: 'web-design',
    title: 'Web Design',
    description: 'Criamos interfaces digitais que combinam estética, organização, identidade visual e facilidade de navegação.',
    icon: Palette,
    badge: 'UI / UX Design',
    tagColor: 'text-[#219AB5] bg-[#219AB5]/10',
  },
  {
    id: 'identidade-visual',
    title: 'Identidade Visual e Design Gráfico',
    description: 'Desenvolvemos soluções visuais que valorizam a personalidade de cada marca, com criatividade e coerência estética.',
    icon: Sparkles,
    badge: 'Branding & Arte',
    tagColor: 'text-[#FFB900] bg-[#FFB900]/15',
  },
  {
    id: 'seo-otimizacao',
    title: 'SEO e Otimização',
    description: 'Aplicamos técnicas básicas de otimização para mecanismos de busca, melhorando a estrutura dos sites e suas possibilidades de descoberta no Google.',
    icon: Search,
    badge: 'Visibilidade Google',
    tagColor: 'text-[#219AB5] bg-[#219AB5]/10',
  },
  {
    id: 'manutencao-atualizacao',
    title: 'Manutenção e Atualização',
    description: 'Realizamos ajustes, correções e pequenas atualizações para manter os projetos organizados e funcionais.',
    icon: Wrench,
    badge: 'Suporte Contínuo',
    tagColor: 'text-[#003047] bg-[#003047]/10',
  },
];

export const Services: React.FC = () => {
  return (
    <div id="servicos" className="relative bg-[#F8F7F2] border-t border-slate-200/80">
      
      {/* ========================================================= */}
      {/* 2. SEÇÃO PRINCIPAL — NOSSOS SERVIÇOS                      */}
      {/* ========================================================= */}
      <section className="relative pt-24 pb-20 md:pt-32 md:pb-24 overflow-hidden">
        {/* Subtle geometric background shapes */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#219AB5]/5 rounded-bl-full pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-72 h-72 bg-[#FFB900]/5 rounded-tr-full pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            
            {/* Tagline kicker */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#003047]/5 text-[#003047] text-xs font-bold tracking-[0.2em] uppercase mb-6">
              <span className="w-2 h-2 rounded-full bg-[#219AB5]" />
              <span>FORMA STUDIO · SERVIÇOS</span>
            </div>

            {/* Main Title */}
            <h1 
              className="text-4xl sm:text-5xl lg:text-6xl font-black text-[#003047] tracking-tight leading-[1.08] mb-6 uppercase text-balance"
              style={{ fontFamily: "'Space Grotesk', 'Plus Jakarta Sans', sans-serif" }}
            >
              SUA IDEIA MERECE <span className="text-[#219AB5]">GANHAR FORMA.</span>
            </h1>

            {/* Subtitle */}
            <p className="text-lg sm:text-xl text-slate-700 font-normal leading-relaxed mb-10 max-w-2xl mx-auto">
              Unimos arte, design e tecnologia para transformar ideias em experiências digitais criativas, funcionais e personalizadas.
            </p>

            {/* CTA Button: Conheça nossos planos */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="#planos"
                className="inline-flex items-center justify-center gap-2.5 px-8 py-4 text-sm font-bold tracking-wider uppercase text-white bg-[#003047] hover:bg-[#002233] rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 active:scale-[0.98] group"
              >
                <span>Conheça nossos planos</span>
                <ArrowDown className="w-4 h-4 text-[#8CCBE3] group-hover:translate-y-0.5 transition-transform" />
              </a>

              <a
                href={getWhatsAppUrl('Olá, Elisson! Estive na aba de Serviços da Forma Studio e gostaria de conversar sobre meu projeto.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-4 text-sm font-semibold text-[#003047] hover:text-[#219AB5] bg-white hover:bg-slate-50 border border-slate-200/90 rounded-xl transition-all shadow-sm"
              >
                <MessageSquare className="w-4 h-4 text-[#219AB5]" />
                <span>Conversar no WhatsApp</span>
              </a>
            </div>

          </div>
        </div>
      </section>

      {/* ========================================================= */}
      {/* 3. SEÇÃO — O QUE FAZEMOS?                                 */}
      {/* ========================================================= */}
      <section className="py-20 md:py-24 bg-white border-y border-slate-200/80 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section Header */}
          <div className="max-w-3xl mb-16">
            <div className="flex items-center gap-2 text-xs font-bold tracking-[0.2em] uppercase text-[#219AB5] mb-3">
              <span>SOLUÇÕES COMPLETAS</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>ESTRUTURA & DESIGN</span>
            </div>
            <h2 
              className="text-3xl sm:text-4xl font-extrabold text-[#003047] tracking-tight mb-4 uppercase"
              style={{ fontFamily: "'Space Grotesk', 'Plus Jakarta Sans', sans-serif" }}
            >
              O QUE FAZEMOS?
            </h2>
            <p className="text-base text-slate-600 leading-relaxed max-w-2xl">
              Cada serviço é executado com rigor estético e técnico, garantindo uma presença digital profissional, ágil e focada em resultados.
            </p>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SERVICES_LIST.map((service) => {
              const Icon = service.icon;
              return (
                <div
                  key={service.id}
                  className="bg-[#F8F7F2] rounded-2xl p-7 border border-slate-200/90 hover:border-[#219AB5]/40 hover:shadow-xl transition-all duration-300 flex flex-col justify-between group hover:-translate-y-1"
                >
                  <div>
                    {/* Top Row: Icon & Category Badge */}
                    <div className="flex items-center justify-between mb-6">
                      <div className="w-12 h-12 rounded-xl bg-white border border-slate-200/80 text-[#003047] flex items-center justify-center shadow-sm group-hover:bg-[#003047] group-hover:text-white transition-colors duration-300">
                        <Icon className="w-6 h-6 transition-transform duration-300 group-hover:scale-110" />
                      </div>
                      <span className={`text-[11px] font-bold uppercase tracking-wider px-3 py-1 rounded-md ${service.tagColor}`}>
                        {service.badge}
                      </span>
                    </div>

                    {/* Service Title */}
                    <h3 className="text-lg font-bold text-[#003047] mb-3 group-hover:text-[#219AB5] transition-colors">
                      {service.title}
                    </h3>

                    {/* Service Description */}
                    <p className="text-sm text-slate-600 leading-relaxed font-normal">
                      {service.description}
                    </p>
                  </div>

                  {/* WhatsApp Quick Link */}
                  <div className="mt-6 pt-5 border-t border-slate-200/70 flex items-center justify-between text-xs">
                    <a
                      href={getServiceWhatsAppUrl(service.title)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 font-bold text-[#003047] hover:text-[#219AB5] transition-colors"
                    >
                      <span>Solicitar proposta</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    </a>
                    <span className="text-slate-400 font-mono text-[11px]">Forma Studio</span>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </section>

      {/* ========================================================= */}
      {/* 4. SEÇÃO — NOSSOS PLANOS                                  */}
      {/* ========================================================= */}
      <section id="planos" className="py-24 bg-[#F8F7F2] relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section Header */}
          <div className="max-w-3xl mx-auto text-center mb-14">
            <div className="inline-flex items-center gap-2 text-xs font-bold tracking-[0.2em] uppercase text-[#219AB5] mb-3">
              <span>INVESTIMENTO TRANSPARENTE</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>PACOTES COMERCIAIS</span>
            </div>
            
            <h2 
              className="text-3xl sm:text-5xl font-black text-[#003047] tracking-tight mb-4 uppercase"
              style={{ fontFamily: "'Space Grotesk', 'Plus Jakarta Sans', sans-serif" }}
            >
              PLANOS DE DESENVOLVIMENTO DE SITES
            </h2>
            
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl mx-auto">
              Cada projeto tem suas próprias necessidades. Por isso, oferecemos soluções que acompanham diferentes objetivos e investimentos.
            </p>
          </div>

          {/* Official Plans Poster Graphic (Strict 1:1 Preservation, uncropped, clean display) */}
          <div className="w-full max-w-4xl mx-auto mb-12">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-slate-200/90 bg-white p-2 sm:p-4">
              <img
                src={planosImg}
                alt="Planos de Desenvolvimento de Sites — Forma Studio: Site Simples, Site Essencial e Site Premium"
                className="w-full h-auto object-contain mx-auto rounded-2xl"
                style={{
                  width: '100%',
                  height: 'auto',
                  aspectRatio: '1 / 1',
                  objectFit: 'contain',
                }}
              />
            </div>
          </div>

          {/* Direct Plan Selection Buttons for WhatsApp */}
          <div className="max-w-4xl mx-auto bg-white rounded-2xl p-6 sm:p-8 border border-slate-200/90 shadow-md">
            <div className="text-center mb-6">
              <h3 className="text-lg font-bold text-[#003047] mb-1">
                Escolha o plano ideal e converse diretamente com Elisson Barbosa
              </h3>
              <p className="text-xs text-slate-500">
                Atendimento rápido pelo WhatsApp: <strong className="text-slate-800">{WHATSAPP_DISPLAY_PHONE}</strong>
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Plano 1 */}
              <a
                href={getWhatsAppUrl('Olá, Elisson! Gostaria de contratar o plano *SITE SIMPLES* (R$ 200,00) da Forma Studio.')}
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 rounded-xl bg-[#D7EFF7]/70 hover:bg-[#D7EFF7] border border-[#BBE1EF] flex flex-col items-center text-center transition-all hover:scale-[1.02] active:scale-[0.98] group"
              >
                <span className="text-xs font-bold text-[#219AB5] uppercase tracking-wider mb-0.5">Plano 01</span>
                <span className="text-sm font-extrabold text-[#003047] mb-1">Site Simples</span>
                <span className="text-xs font-bold text-[#219AB5] mb-3">R$ 200,00 (único)</span>
                <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#003047] group-hover:text-[#219AB5]">
                  <span>Contratar no WhatsApp</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </a>

              {/* Plano 2 */}
              <a
                href={getWhatsAppUrl('Olá, Elisson! Gostaria de conversar sobre o plano *SITE ESSENCIAL* (R$ 200 à R$ 500) da Forma Studio.')}
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 rounded-xl bg-white hover:bg-slate-50 border-2 border-[#219AB5] flex flex-col items-center text-center transition-all hover:scale-[1.02] active:scale-[0.98] shadow-sm group"
              >
                <span className="text-xs font-bold text-[#219AB5] uppercase tracking-wider mb-0.5">Mais Procurado</span>
                <span className="text-sm font-extrabold text-[#003047] mb-1">Site Essencial</span>
                <span className="text-xs font-bold text-[#219AB5] mb-3">R$ 200 à 500,00</span>
                <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#003047] group-hover:text-[#219AB5]">
                  <span>Contratar no WhatsApp</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </a>

              {/* Plano 3 */}
              <a
                href={getWhatsAppUrl('Olá, Elisson! Quero solicitar uma proposta para o plano *SITE PREMIUM* (R$ 500 à R$ 1.000) da Forma Studio.')}
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 rounded-xl bg-[#003047] hover:bg-[#002233] text-white flex flex-col items-center text-center transition-all hover:scale-[1.02] active:scale-[0.98] shadow-md group"
              >
                <span className="text-xs font-bold text-[#8CCBE3] uppercase tracking-wider mb-0.5">Completo</span>
                <span className="text-sm font-extrabold text-white mb-1">Site Premium</span>
                <span className="text-xs font-bold text-[#8CCBE3] mb-3">R$ 500 à 1.000,00</span>
                <span className="inline-flex items-center gap-1.5 text-xs font-bold text-white group-hover:text-[#8CCBE3]">
                  <span>Contratar no WhatsApp</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </a>
            </div>

            {/* Inclusão de suporte */}
            <div className="mt-6 pt-5 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Todos os planos incluem <strong>3 manutenções gratuitas</strong> pós-entrega.</span>
              </div>
              <span className="text-slate-500">Sem mensalidades forçadas ou taxas escondidas.</span>
            </div>
          </div>

        </div>
      </section>

    </div>
  );
};
