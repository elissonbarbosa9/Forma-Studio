import React from 'react';
import { FormaLogo } from './FormaLogo';
import { getWhatsAppUrl, WHATSAPP_DISPLAY_PHONE, INSTAGRAM_URL, INSTAGRAM_HANDLE } from '../utils/whatsapp';
import { MessageSquare, Mail, ArrowUpRight, Instagram } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-navy text-white pt-20 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 pb-16 border-b border-slate-800">
          
          {/* Brand & Manifesto */}
          <div className="md:col-span-5 flex flex-col items-start">
            <FormaLogo variant="full" size="md" theme="dark" className="mb-6" />
            
            <p className="text-sm text-slate-300 leading-relaxed max-w-sm mb-6">
              A FORMA STUDIO une arte, design e tecnologia para desenvolver soluções digitais criativas, acessíveis e personalizadas para marcas que desejam se destacar no Brasil e no mundo.
            </p>

            <div className="flex items-center gap-3 text-xs text-slate-400">
              <span>Fundada por Elisson Barbosa</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Nordeste, Brasil</span>
            </div>
          </div>

          {/* Quick Navigation Links */}
          <div className="md:col-span-3">
            <span className="text-xs font-bold uppercase tracking-widest text-brand-cyan-light block mb-4">
              Navegação
            </span>
            <ul className="space-y-3 text-sm text-slate-300">
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">
                  Serviços Oferecidos
                </a>
              </li>
              <li>
                <a href="#planos" className="hover:text-white transition-colors">
                  Planos & Pacotes
                </a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-white transition-colors">
                  Portfólio de Projetos
                </a>
              </li>
              <li>
                <a href="#sobre" className="hover:text-white transition-colors">
                  Sobre Elisson Barbosa
                </a>
              </li>
              <li>
                <a href="#contato" className="hover:text-white transition-colors">
                  Solicitar Orçamento
                </a>
              </li>
            </ul>
          </div>

          {/* Direct Contact & Social */}
          <div className="md:col-span-4 flex flex-col">
            <span className="text-xs font-bold uppercase tracking-widest text-brand-cyan-light block mb-4">
              Atendimento Direto
            </span>
            
            <div className="space-y-3 text-sm mb-6">
              <a
                href={getWhatsAppUrl('Olá, Elisson! Vim pelo rodapé da Forma Studio e quero um orçamento.')}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 text-slate-200 hover:text-white group"
              >
                <MessageSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>WhatsApp: <strong>{WHATSAPP_DISPLAY_PHONE}</strong></span>
                <ArrowUpRight className="w-3.5 h-3.5 opacity-50 group-hover:opacity-100 transition-opacity" />
              </a>

              <a
                href="mailto:elissonbarbosa9@gmail.com"
                className="flex items-center gap-2.5 text-slate-200 hover:text-white group"
              >
                <Mail className="w-4 h-4 text-brand-cyan-light shrink-0" />
                <span>elissonbarbosa9@gmail.com</span>
                <ArrowUpRight className="w-3.5 h-3.5 opacity-50 group-hover:opacity-100 transition-opacity" />
              </a>

              <a
                href={INSTAGRAM_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 text-slate-200 hover:text-white group"
              >
                <Instagram className="w-4 h-4 text-pink-400 shrink-0" />
                <span>Instagram: <strong>{INSTAGRAM_HANDLE}</strong></span>
                <ArrowUpRight className="w-3.5 h-3.5 opacity-50 group-hover:opacity-100 transition-opacity" />
              </a>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Atendimento de segunda a sexta, das 08h às 19h. Respostas prioritárias pelo WhatsApp.
            </p>
          </div>

        </div>

        {/* Bottom Copyright bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            © {new Date().getFullYear()} Forma Studio · Arte, Design & Web. Todos os direitos reservados.
          </div>
          
          <div className="flex items-center gap-1 text-slate-400">
            <span>Desenvolvido com excelência técnica & olhar autoral</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
