import React from 'react';
import formaSimboloImg from '../assets/images/forma_simbolo_oficial.png';

interface FormaLogoProps {
  variant?: 'full' | 'compact' | 'symbol';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  theme?: 'dark' | 'light';
  className?: string;
}

export const FormaLogo: React.FC<FormaLogoProps> = ({
  variant = 'compact',
  size = 'md',
  theme = 'light',
  className = '',
}) => {
  const isDark = theme === 'dark';

  // Sizing maps
  const symbolSizes = {
    sm: 'w-7 h-8',
    md: 'w-9 h-10',
    lg: 'w-14 h-16',
    xl: 'w-20 h-22',
  };

  const textSizes = {
    sm: { forma: 'text-sm tracking-wider', studio: 'text-[9px] tracking-[0.25em]' },
    md: { forma: 'text-lg tracking-wider font-extrabold', studio: 'text-[11px] tracking-[0.3em] font-semibold' },
    lg: { forma: 'text-3xl tracking-wider font-extrabold', studio: 'text-sm tracking-[0.35em] font-semibold' },
    xl: { forma: 'text-5xl tracking-widest font-black', studio: 'text-lg tracking-[0.4em] font-bold' },
  };

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Símbolo Original Oficial (Arquivo estático exato sem modificações de forma ou cor) */}
      <img
        src={formaSimboloImg}
        alt="Símbolo oficial Forma Studio"
        className={`${symbolSizes[size]} shrink-0 object-contain logo-pulse-hover cursor-pointer`}
      />

      {/* Typography Lockup */}
      {variant !== 'symbol' && (
        <div className="flex flex-col justify-center leading-none">
          <span
            className={`font-display uppercase ${textSizes[size].forma} ${
              isDark ? 'text-white' : 'text-brand-navy'
            }`}
            style={{ fontFamily: "'Space Grotesk', 'Plus Jakarta Sans', sans-serif", letterSpacing: '0.12em' }}
          >
            FORMA
          </span>
          <span
            className={`uppercase ${textSizes[size].studio} text-brand-cyan mt-1`}
            style={{ letterSpacing: '0.3em' }}
          >
            STUDIO
          </span>

          {variant === 'full' && (
            <div className="flex items-center gap-1.5 mt-2 text-[10px] uppercase font-medium tracking-[0.22em] text-slate-500">
              <span>ARTE</span>
              <span className="text-brand-cyan">/</span>
              <span>DESIGN</span>
              <span className="text-brand-gold">/</span>
              <span>WEB</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
