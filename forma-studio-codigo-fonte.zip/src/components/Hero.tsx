import React from 'react';
import { getWhatsAppUrl, WHATSAPP_DISPLAY_PHONE } from '../utils/whatsapp';
import { ArrowRight, MessageSquare, Sparkles, CheckCircle2, ShieldCheck, Zap } from 'lucide-react';
import heroBrandImage from '../assets/images/regenerated_image_1792092284637.png';

export const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden bg-gradient-to-b from-slate-50/70 via-white to-white">
      {/* Subtle geometric background grid pattern */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.035]"
        style={{
          backgroundImage: `radial-gradient(#0A2540 1px, transparent 1px)`,
          backgroundSize: '28px 28px',
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Typographic Hierarchy */}
          <div className="lg:col-span-7 flex flex-col items-start">
            
            {/* Kicker / Subtitle (Clean unboxed text, no pill wrapper) */}
            <div className="flex items-center gap-2.5 text-xs font-semibold tracking-[0.2em] uppercase text-brand-cyan mb-4">
              <span>FORMA STUDIO</span>
              <span aria-hidden="true" className="text-slate-300">/</span>
              <span className="text-brand-navy">ARTE</span>
              <span aria-hidden="true" className="text-slate-300">/</span>
              <span className="text-brand-gold">DESIGN</span>
              <span aria-hidden="true" className="text-slate-300">/</span>
              <span className="text-brand-cyan">WEB</span>
            </div>

            {/* Display Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-brand-navy tracking-tight leading-[1.08] mb-6 text-balance">
              Arte, design e tecnologia para projetos digitais de{' '}
              <span className="relative inline-block text-brand-navy">
                alto padrão.
                <span
                  className="absolute bottom-1.5 left-0 w-full h-[6px] bg-brand-cyan/20 -z-10 rounded-sm"
                  aria-hidden="true"
                />
              </span>
            </h1>

            {/* Lead Narrative */}
            <p className="text-lg sm:text-xl text-slate-600 font-normal leading-relaxed mb-8 max-w-2xl">
              Desenvolvemos sites modernos, landing pages de alta conversão e identidades visuais marcantes. Unimos a sensibilidade artística à precisão técnica para transformar o seu negócio em uma referência inquestionável.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto mb-10">
              <a
                href={getWhatsAppUrl('Olá, Elisson! Estive no site da Forma Studio e quero solicitar uma proposta para meu projeto.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 px-7 py-4 text-sm font-bold tracking-wide uppercase text-white bg-brand-navy hover:bg-brand-navy-dark rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 active:scale-[0.98] group"
              >
                <MessageSquare className="w-4 h-4 text-brand-cyan-light group-hover:scale-110 transition-transform" />
                <span>Solicitar Orçamento no WhatsApp</span>
                <ArrowRight className="w-4 h-4 text-slate-300 group-hover:translate-x-0.5 transition-transform" />
              </a>

              <a
                href="#portfolio"
                className="inline-flex items-center justify-center gap-2 px-6 py-4 text-sm font-semibold text-slate-700 hover:text-brand-navy bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-all duration-200 shadow-sm"
              >
                <span>Ver Projetos Selecionados</span>
              </a>
            </div>

            {/* Direct Trust Metadata */}
            <div className="flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Atendimento direto pelo WhatsApp: <strong className="text-slate-800">{WHATSAPP_DISPLAY_PHONE}</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-brand-cyan shrink-0" />
                <span>Atendimento em todo o Brasil</span>
              </div>
            </div>

          </div>

          {/* Right Column: Visual Showcase Container */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-lg lg:max-w-none">
              
              {/* Aesthetic Backdrop Glow */}
              <div
                className="absolute -inset-2 bg-gradient-to-tr from-brand-cyan/20 to-brand-gold/15 rounded-3xl blur-2xl opacity-70 -z-10"
                aria-hidden="true"
              />

              {/* Main Visual Frame */}
              <div className="relative rounded-2xl overflow-hidden border border-slate-200/90 bg-[#F7F5F0] shadow-2xl">
                {/* Browser-style minimal window bar */}
                <div className="bg-slate-100/90 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-rose-400" />
                    <div className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                  </div>
                  <span className="text-[11px] font-mono text-slate-500">formastudio.com.br · Identidade Oficial</span>
                  <div className="w-6" />
                </div>

                <div className="relative aspect-[4/3] bg-[#F7F5F0] overflow-hidden flex items-center justify-center p-3 sm:p-5">
                  <img
                    src={heroBrandImage}
                    alt="Logotipo geométrico oficial da Forma Studio — Arte / Design / Web"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain transition-transform duration-700 hover:scale-[1.03]"
                  />
                  
                  <div className="absolute inset-x-0 bottom-0 py-2.5 px-4 bg-white/80 backdrop-blur-sm border-t border-slate-200/60 flex items-center justify-between text-xs text-slate-600">
                    <span className="font-semibold text-brand-navy text-[11px] uppercase tracking-wider">Identidade Autoral</span>
                    <span className="text-slate-400 text-[11px]">Arte · Design · Web</span>
                  </div>
                </div>
              </div>

              {/* Floating Stat Card (Functional contextual proof) */}
              <div className="hidden sm:flex absolute -bottom-6 -left-6 bg-white border border-slate-200/90 rounded-xl p-4 shadow-xl items-center gap-3.5 z-20">
                <div className="w-10 h-10 rounded-lg bg-brand-navy flex items-center justify-center text-brand-gold shrink-0">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-500 font-medium">Foco em Conversão</div>
                  <div className="text-sm font-extrabold text-brand-navy">Design 100% Exclusivo</div>
                </div>
              </div>

              <div className="hidden sm:flex absolute -top-5 -right-5 bg-white border border-slate-200/90 rounded-xl p-3.5 shadow-xl items-center gap-3 z-20">
                <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
                  <Zap className="w-4 h-4" />
                </div>
                <div className="text-xs">
                  <span className="font-bold text-slate-900">Performance Rápida</span>
                  <span className="block text-slate-500 text-[11px]">Nota 95+ no PageSpeed</span>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* 4-Pillar Proof Strip below Hero (Strict 1-section adjacency rule) */}
        <div className="mt-20 pt-10 border-t border-slate-200/80 grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          <div className="flex flex-col">
            <span className="text-2xl font-black text-brand-navy tracking-tight font-display">100%</span>
            <span className="text-sm font-semibold text-slate-900 mt-1">Design Autoral</span>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Sem temas genéricos pré-fabricados. Cada projeto é desenhado para sua marca.
            </p>
          </div>

          <div className="flex flex-col">
            <span className="text-2xl font-black text-brand-navy tracking-tight font-display">+180%</span>
            <span className="text-sm font-semibold text-slate-900 mt-1">Foco em Conversão</span>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Estrutura planejada para guiar o visitante até a solicitação de orçamento.
            </p>
          </div>

          <div className="flex flex-col">
            <span className="text-2xl font-black text-brand-navy tracking-tight font-display">Mobile</span>
            <span className="text-sm font-semibold text-slate-900 mt-1">Responsividade Total</span>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Experiência impecável em smartphones, tablets e telas de alta resolução.
            </p>
          </div>

          <div className="flex flex-col">
            <span className="text-2xl font-black text-brand-navy tracking-tight font-display">Direto</span>
            <span className="text-sm font-semibold text-slate-900 mt-1">Contato com Fundador</span>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Você lida diretamente com Elisson Barbosa, sem intermediários ou ruídos.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
