import React, { useState } from 'react';
import { 
  WHATSAPP_RAW_PHONE, 
  WHATSAPP_DISPLAY_PHONE, 
  getWhatsAppUrl,
  INSTAGRAM_URL,
  INSTAGRAM_HANDLE
} from '../utils/whatsapp';
import { 
  Send, 
  MessageSquare, 
  CheckCircle2, 
  Mail, 
  Phone, 
  MapPin, 
  Clock, 
  Sparkles,
  Instagram
} from 'lucide-react';

export const ContactForm: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    businessType: 'Profissional Autônomo / Liberal',
    service: 'Criação e Desenvolvimento de Site',
    deadline: 'Dentro de 15 a 30 dias',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleSendViaWhatsApp = () => {
    const formattedText = `*Solicitação de Orçamento - Forma Studio*
*Nome:* ${formData.name || 'Não informado'}
*Telefone:* ${formData.phone || 'Não informado'}
*Perfil/Negócio:* ${formData.businessType}
*Serviço de Interesse:* ${formData.service}
*Prazo Desejado:* ${formData.deadline}
*Detalhes do Projeto:* ${formData.message || 'Gostaria de agendar uma conversa para detalhar o projeto.'}`;

    const url = `https://wa.me/${WHATSAPP_RAW_PHONE}?text=${encodeURIComponent(formattedText)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contato" className="py-24 bg-slate-50/70 border-t border-slate-200/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 pb-6 border-b border-slate-200">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold tracking-[0.2em] uppercase text-brand-cyan mb-3">
              <span>FORMA STUDIO</span>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span>ORÇAMENTO & CONTATO</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-brand-navy tracking-tight text-balance">
              Vamos tirar a sua ideia do papel e transformá-la em autoridade digital.
            </h2>
          </div>
          
          <p className="mt-4 md:mt-0 text-sm text-slate-600 max-w-sm leading-relaxed">
            Preencha os campos abaixo ou entre em contato diretamente pelo WhatsApp para receber uma proposta personalizada.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          
          {/* Left Column: Direct Contact Details & Guarantees */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-8">
            <div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">
                Canais de Atendimento Direto
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed mb-8">
                Na Forma Studio você conversa diretamente com Elisson Barbosa. Sem triagens demoradas ou respostas automáticas robóticas.
              </p>

              {/* Direct Cards */}
              <div className="space-y-4">
                {/* WhatsApp Card */}
                <a
                  href={getWhatsAppUrl('Olá, Elisson! Gostaria de tirar algumas dúvidas antes de fechar um orçamento.')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-5 bg-white rounded-2xl border border-slate-200/90 hover:border-brand-navy/30 hover:shadow-md transition-all flex items-start gap-4 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide block">
                      WhatsApp Oficial (Mais Rápido)
                    </span>
                    <span className="text-base font-bold text-slate-900 group-hover:text-brand-navy transition-colors">
                      {WHATSAPP_DISPLAY_PHONE}
                    </span>
                    <span className="text-xs text-slate-500 block mt-0.5">
                      Clique para abrir conversa instantânea
                    </span>
                  </div>
                </a>

                {/* Email Card */}
                <a
                  href="mailto:elissonbarbosa9@gmail.com"
                  className="p-5 bg-white rounded-2xl border border-slate-200/90 hover:border-brand-navy/30 hover:shadow-md transition-all flex items-start gap-4 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-blue-50 text-brand-navy flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide block">
                      E-mail Profissional
                    </span>
                    <span className="text-base font-bold text-slate-900 group-hover:text-brand-navy transition-colors">
                      elissonbarbosa9@gmail.com
                    </span>
                    <span className="text-xs text-slate-500 block mt-0.5">
                      Envio de briefings, arquivos e contratos
                    </span>
                  </div>
                </a>

                {/* Instagram Card */}
                <a
                  href={INSTAGRAM_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-5 bg-white rounded-2xl border border-slate-200/90 hover:border-pink-500/40 hover:shadow-md transition-all flex items-start gap-4 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-pink-50 text-pink-600 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                    <Instagram className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide block">
                      Instagram Oficial
                    </span>
                    <span className="text-base font-bold text-slate-900 group-hover:text-pink-600 transition-colors">
                      {INSTAGRAM_HANDLE}
                    </span>
                    <span className="text-xs text-slate-500 block mt-0.5">
                      Siga para ver bastidores, novidades e projetos
                    </span>
                  </div>
                </a>

                {/* Location & Hours Card */}
                <div className="p-5 bg-white rounded-2xl border border-slate-200/90 flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide block">
                      Disponibilidade & Região
                    </span>
                    <span className="text-sm font-bold text-slate-900">
                      Segunda a Sexta · 08h às 19h
                    </span>
                    <span className="text-xs text-slate-500 block mt-0.5">
                      Atendimento para clientes em todo o Brasil
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Commitment Box */}
            <div className="p-6 bg-brand-navy text-white rounded-2xl relative overflow-hidden">
              <div className="flex items-center gap-2 text-brand-cyan-light text-xs font-bold uppercase tracking-wider mb-2">
                <Sparkles className="w-4 h-4" />
                <span>Compromisso Forma Studio</span>
              </div>
              <p className="text-xs text-slate-200 leading-relaxed">
                Todas as propostas incluem escopo detalhado por escrito, cronograma de entrega e garantia de suporte pós-lançamento.
              </p>
            </div>
          </div>

          {/* Right Column: Interactive Form */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-2xl border border-slate-200/90 p-8 sm:p-10 shadow-lg">
              
              {submitted ? (
                <div className="py-12 flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mb-6">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-bold text-brand-navy mb-3">
                    Solicitação Preparada com Sucesso!
                  </h3>
                  <p className="text-sm text-slate-600 max-w-md leading-relaxed mb-8">
                    Obrigado pelo contato! Para receber sua estimativa e conversar em tempo real, clique no botão abaixo para abrir a conversa com os seus dados no WhatsApp.
                  </p>
                  
                  <div className="flex flex-col sm:flex-row gap-4 w-full justify-center max-w-md">
                    <button
                      type="button"
                      onClick={handleSendViaWhatsApp}
                      className="w-full inline-flex items-center justify-center gap-2 px-6 py-4 text-xs font-bold uppercase tracking-wide text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-all"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>Abrir Agora no WhatsApp</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setSubmitted(false)}
                      className="w-full sm:w-auto px-5 py-4 text-xs font-semibold text-slate-600 hover:text-slate-900 border border-slate-200 rounded-xl"
                    >
                      Editar Dados
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  
                  <div className="border-b border-slate-100 pb-4 mb-6">
                    <h3 className="text-xl font-bold text-brand-navy">
                      Solicitar Orçamento Personalizado
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">
                      Leva menos de 1 minuto e você recebe retorno direto de Elisson Barbosa.
                    </p>
                  </div>

                  {/* Name & Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                        Seu Nome ou Empresa *
                      </label>
                      <input
                        type="text"
                        id="name"
                        required
                        placeholder="Ex: João da Silva / Silva Imóveis"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-4 py-3 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-brand-navy focus:bg-white transition-colors"
                      />
                    </div>

                    <div>
                      <label htmlFor="phone" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                        WhatsApp com DDD *
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        required
                        placeholder="Ex: (87) 99999-9999"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-4 py-3 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-brand-navy focus:bg-white transition-colors"
                      />
                    </div>
                  </div>

                  {/* Segment / Business Type & Service */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="businessType" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                        Seu Perfil / Negócio
                      </label>
                      <select
                        id="businessType"
                        value={formData.businessType}
                        onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
                        className="w-full px-4 py-3 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-brand-navy focus:bg-white transition-colors"
                      >
                        <option>Profissional Autônomo / Liberal</option>
                        <option>Microempreendedor Individual (MEI)</option>
                        <option>Pequena ou Média Empresa</option>
                        <option>Artista / Criador de Conteúdo</option>
                        <option>Comércio / Prestador de Serviços</option>
                        <option>Outro segmento</option>
                      </select>
                    </div>

                    <div>
                      <label htmlFor="service" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                        Serviço Principal
                      </label>
                      <select
                        id="service"
                        value={formData.service}
                        onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                        className="w-full px-4 py-3 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-brand-navy focus:bg-white transition-colors"
                      >
                        <option>Criação e Desenvolvimento de Site</option>
                        <option>Landing Page de Alta Conversão</option>
                        <option>Web Design & UI/UX</option>
                        <option>Identidade Visual & Branding</option>
                        <option>Artes Visuais & Mídias Digitais</option>
                        <option>Otimização SEO & Manutenção</option>
                        <option>Solução Digital Personalizada</option>
                      </select>
                    </div>
                  </div>

                  {/* Deadline */}
                  <div>
                    <label htmlFor="deadline" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                      Expectativa de Prazo
                    </label>
                    <select
                      id="deadline"
                      value={formData.deadline}
                      onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                      className="w-full px-4 py-3 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-brand-navy focus:bg-white transition-colors"
                    >
                      <option>Urgente (menos de 15 dias)</option>
                      <option>Dentro de 15 a 30 dias</option>
                      <option>Para o próximo trimestre</option>
                      <option>Apenas pesquisando valores</option>
                    </select>
                  </div>

                  {/* Message / Briefing details */}
                  <div>
                    <label htmlFor="message" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                      Conte um pouco sobre o que você deseja
                    </label>
                    <textarea
                      id="message"
                      rows={3}
                      placeholder="Descreva seu objetivo, referências que você gosta ou dúvidas sobre o projeto..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-4 py-3 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-brand-navy focus:bg-white transition-colors resize-none"
                    />
                  </div>

                  {/* Actions buttons: WhatsApp Direct & Form Submit */}
                  <div className="pt-2 flex flex-col sm:flex-row gap-4">
                    <button
                      type="button"
                      onClick={handleSendViaWhatsApp}
                      className="flex-1 inline-flex items-center justify-center gap-2.5 px-6 py-4 text-xs font-bold uppercase tracking-wider text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-all active:scale-[0.98]"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>Enviar e Abrir no WhatsApp</span>
                    </button>

                    <button
                      type="submit"
                      className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-4 text-xs font-bold uppercase tracking-wider text-white bg-brand-navy hover:bg-brand-navy-dark rounded-xl shadow-md transition-all active:scale-[0.98]"
                    >
                      <Send className="w-4 h-4 text-brand-cyan-light" />
                      <span>Enviar Mensagem</span>
                    </button>
                  </div>

                  <p className="text-[11px] text-slate-400 text-center">
                    Seus dados estão protegidos. Não enviamos spam nem compartilhamos suas informações.
                  </p>

                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
